export const metadata = {
    title: "개인정보처리방침 | 아이스마일어게인",
    description: "아이스마일어게인 개인정보처리방침",
    alternates: {
      canonical: "https://www.ismileagain.co.kr/privacy",
    },
  };
  
  export default function PrivacyPage() {
    return (
      <main
        style={{
          maxWidth: "1000px",
          margin: "80px auto",
          padding: "24px",
          lineHeight: "1.9",
        }}
      >
        <h1 style={{ marginBottom: "30px" }}>개인정보처리방침</h1>
  
        <p>
          아이스마일어게인(이하 &quot;회사&quot;)은 개인정보보호법 등 관련 법령을
          준수하며 고객님의 개인정보를 안전하게 보호하고 있습니다.
        </p>
  
        <h2>1. 수집하는 개인정보 항목</h2>
        <p>
          회사는 온라인 접수 및 상담 서비스를 위해 아래와 같은 개인정보를
          수집할 수 있습니다.
        </p>
  
        <ul>
          <li>이름</li>
          <li>연락처</li>
          <li>기기명 및 모델명</li>
          <li>고장 증상</li>
          <li>문의 내용</li>
        </ul>
  
        <h2>2. 개인정보 수집 목적</h2>
  
        <ul>
          <li>수리 상담 및 접수 진행</li>
          <li>고객 문의 응대</li>
          <li>수리 진행 상황 안내</li>
          <li>서비스 품질 향상</li>
        </ul>
  
        <h2>3. 개인정보 보유 및 이용기간</h2>
  
        <p>
          수집된 개인정보는 서비스 제공 목적 달성 후 지체 없이 파기합니다.
          단, 관련 법령에 따라 일정 기간 보관이 필요한 경우 해당 기간 동안
          보관할 수 있습니다.
        </p>
  
        <h2>4. 개인정보 제3자 제공</h2>
  
        <p>
          회사는 고객님의 개인정보를 외부에 판매하거나 제공하지 않습니다.
        </p>
  
        <h2>5. 개인정보 보호 책임자</h2>
  
        <p>
          상호 : 아이스마일어게인
          <br />
          대표자 : 양용환
          <br />
          사업자등록번호 : 542-52-00920
          <br />
          대표전화 : 02-3424-5295
        </p>
  
        <h2>6. 개인정보처리방침 시행일</h2>
  
        <p>시행일 : 2026년 6월 16일</p>
      </main>
    );
  }
